package br.com.firstdatacorp.brtmpmicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrtmpmicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrtmpmicroservicesApplication.class, args);
	}

}
